package lib;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;



public class Capture {

	public static void screenShot (WebDriver driver, String screenshotName) throws IOException {
		
		TakesScreenshot scrShot =(TakesScreenshot) driver;
		File SrcFile=scrShot.getScreenshotAs(OutputType.FILE);
		String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(Calendar.getInstance().getTime());
		FileUtils.copyFile(SrcFile, new File("C:\\screenshots\\"+screenshotName+timeStamp+".png "));
	}
}
