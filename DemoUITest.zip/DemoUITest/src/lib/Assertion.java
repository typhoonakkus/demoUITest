package lib;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;


public class Assertion {
	
	public static void assertElementExist(WebDriver driver , WebElement element) throws IOException {
		
		try {
			Assert.assertNotNull(element);
			System.out.println("********Element exist*********");
			Capture.screenShot(driver, "assertion");
		}catch (AssertionError error){
			Capture.screenShot(driver, "assertHata");
			System.out.println("********Assert Fail !!!!!!!*********");
			throw error;
			
		}
	}
	
	public static void assertEquals(WebDriver driver , String actual , String expected) throws IOException {
		
		try {
			Assert.assertEquals(actual, expected);
			System.out.println("********Assertion Success*********");
			Capture.screenShot(driver, "assertion");
		}catch (AssertionError error){
			Capture.screenShot(driver, "assertHata");
			System.out.println("********Assert Fail !!!!!!!*********");
			throw error;
			
		}
	}

}
