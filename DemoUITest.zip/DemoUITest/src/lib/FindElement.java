package lib;


import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;





public class FindElement {
	
	public static WebElement findElement(WebDriver driver, String locatorType, String locator) throws IOException
	{	
	
		int waitTimeout = 10;	
		WebElement element = null;
		
		try {
			
		switch(locatorType) {
		
		case "id":
			System.out.println("*******Start findelement*********");	
			element = findElementById(driver,locator,waitTimeout);
			System.out.println("********Finish find element*********");
		break;
		case "linktext":
			System.out.println("*******Start findelement*********");	
			element = findElementByLinkText(driver,locator,waitTimeout);
			System.out.println("********Finish find element*********");
		break;
		case "xpath":
			System.out.println("*******Start findelement*********");	
			element = findElementByXPath(driver,locator,waitTimeout);
			System.out.println("********Finish find element*********");
		break;
		}
	} catch (Exception e) {
		System.out.println("******Error occured while try to find element!!!!!!!!!"+" "+e+" "+ locator);
		Capture.screenShot(driver, "ErrorFindElement");
		
	}
		return element;

	}


	private static WebElement findElementById (WebDriver driver, String locator, int waitTimeout)
	
	{
		WebElement element = null;
	
		WebDriverWait wait = new WebDriverWait(driver, waitTimeout);
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id(locator)));
		element = driver.findElement(By.id(locator));

		System.out.println("***************findElementById ENABLED DISPLAYED: "+ element.isEnabled() + "\n" +"*******FOUND ELEMENT: " +element);
	
		return element;
	}
	
	private static WebElement findElementByLinkText (WebDriver driver, String locator, int waitTimeout)
	
	{
		WebElement element = null;
	
		WebDriverWait wait = new WebDriverWait(driver, waitTimeout);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText(locator)));
		element = driver.findElement(By.linkText(locator));

		System.out.println("***************findElementByAccessibilityId ENABLED DISPLAYED: "+ element.isEnabled() + "\n" +"*******FOUND ELEMENT: " +element);
	
		return element;
	}
	
private static WebElement findElementByXPath (WebDriver driver, String locator, int waitTimeout)
	
	{
		WebElement element = null;
	
		WebDriverWait wait = new WebDriverWait(driver, waitTimeout);
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(locator)));
		element = driver.findElement(By.xpath(locator));
		
		System.out.println("***************findElementByXPath ENABLED DISPLAYED: "+ element.isEnabled() + "\n" +"*******FOUND ELEMENT: " +element);
	
		return element;
	}
}



