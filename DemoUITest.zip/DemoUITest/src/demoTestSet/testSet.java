package demoTestSet;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import lib.Assertion;
import lib.FindElement;

public class testSet {
	
	public WebDriver driver;
	
	@BeforeTest
	public void openBrowser() {
		
		System.setProperty("webdriver.edge.driver", "C:\\selenium\\MicrosoftWebDriver.exe");
		driver = new EdgeDriver();				
		
	}	
	//Assert for true page coming
	@Test (priority = 0)
	
	public void homePageControl() throws IOException {
		
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(100, TimeUnit.SECONDS);		
		driver.get("http://demoshop24.com/");
		
		String expectedTitle = "Your Store";
		String actualTitle = driver.getTitle();
		Assertion.assertEquals(driver, actualTitle, expectedTitle);		
	}
	
	//search product
	@Test (priority = 1)
	
	public void searchProduct() throws IOException {
		
		WebElement searchEle = FindElement.findElement(driver, "xpath", "//DIV[@id=\"search\"]/input");		
		searchEle.sendKeys("mac");					
		searchEle.sendKeys(Keys.ENTER);
		WebElement assertElement = FindElement.findElement(driver, "xpath", "//DIV[@id=\"content\"]/div[4]/*[contains(.,'Showing')]");
		Assertion.assertElementExist(driver, assertElement);		
	}
	
	// Add to Chart 
	
	@Test (priority = 2)
	
	public void addChart() throws IOException {
		
		WebElement product = FindElement.findElement(driver, "xpath", "//DIV[@id=\"content\"]/div[3]/div[1]/div/div[2]/div[2]/button[1]");		
		product.click();	
		WebElement assertElement = FindElement.findElement(driver, "xpath", "//DIV[@id=\"product-search\"]/div[contains(.,'added')]");
		Assertion.assertElementExist(driver, assertElement);				
		
	}
	
	
	//  Login function test
	@Test  (priority = 3)
	
	public void loginTest() throws IOException {		
		
		WebElement element1 = FindElement.findElement(driver,"xpath" ,"//div[@id=\"top-links\"]/ul/li[2]/a/span[1]");		
		element1.click();
		WebElement element2 = FindElement.findElement(driver, "linktext","Login");
		element2.click();
		WebElement element3 = FindElement.findElement(driver,"id", "input-email");
		element3.sendKeys("typhoonakkus@gmail.com");
		WebElement element4 = FindElement.findElement(driver,"id","input-password");		
		element4.sendKeys("Demo1234");
		WebElement element5 = FindElement.findElement(driver,"xpath", "//div[@id=\"content\"]/div/div[2]/div/form/input");		
		element5.click();
		WebElement assertElement = FindElement.findElement(driver,"linktext", "Edit Account");
		Assertion.assertElementExist(driver, assertElement);				
		
	}

}
